# Saint Nicolas

## Email

- **Subject:** Learn a French greeting for Saint Nicolas
- **Preview text:** French Atelier introduces an eastern French tradition and the words to join in.
- **Headline:** Join a Saint Nicolas celebration in French
- **CTA:** Learn the greeting
- **Destination:** corresponding Saint Nicolas landing page; map to Sandra’s published URL before send.
- **Body word count:** 112 (required 100–130).

Bonjour,

Practise a seasonal French greeting with French Atelier: « Bonne fête de Saint-Nicolas ! » It means “Happy Saint Nicholas Day!”

In Lorraine, Alsace and other parts of eastern France, this Christian bishop is celebrated for generosity. Nancy is known for its processions, where families gather and children look forward to treats.

Look for a bishop’s mitre and curved staff, not Santa’s costume. Pain d’épices shaped like Saint Nicolas is a recognisable gingerbread treat.

Three words help you follow the celebration: un défilé means a parade, les friandises means sweets, and un cadeau means a gift.

Read our guide to understand this regional custom, practise the greeting and use the vocabulary in a French sentence.

[Learn the greeting]

À bientôt,
The French Atelier team

## Landing page

# French greetings and words for Saint Nicolas

Learn how to greet someone and describe a celebration with French Atelier. Saint Nicolas traditions in Lorraine and Alsace give these French words a context: a procession, gifts and a bishop known for generosity. This is a regional custom, not a celebration shared identically across France.

## The person behind the celebration

Saint Nicholas was a Christian bishop of Myra, in what is now Turkey. He became known through stories of generosity and protection, especially towards children. Those stories helped inspire gift-giving customs. In French celebrations, his bishop’s clothing recalls that religious origin: the tall hat is a mitre, and the curved pastoral staff is a crosse.

## A tradition with regional character

Nancy, in Lorraine, is a well-known centre of the festivities. Processions bring Saint Nicolas into the streets, with families watching and children waiting for treats. Customs differ between towns and households. Sweets, small gifts and pain d’épices, or spiced gingerbread, are among the familiar pleasures. Gingerbread figures shaped like the saint make an especially recognisable detail.

## Who is le Père Fouettard?

In some local traditions, Saint Nicolas is accompanied by le Père Fouettard. He is the stern character who contrasts with the generous saint and reminds children about good behaviour. Their contrasting roles are part of the local folklore. Saint Nicolas remains the kindly figure children look forward to meeting, especially when he arrives with treats.

## Practise a greeting and a sentence

Say « Bonne fête de Saint-Nicolas ! » aloud: “Happy Saint Nicholas Day!” Then try « Je regarde le défilé »: “I’m watching the parade.” Un défilé means “a parade”; le défilé means “the parade”. Les friandises means sweets, and un cadeau means a gift. Cover the English meanings and see which words you remember. You now have a greeting to offer and a sentence to describe what you are doing.

Landing-page word count: 299, including section headings; excluding title, branding and references (required 250–350).

## Editorial fact-check references

- [Oxford’s introduction to French Saint Nicolas traditions](https://bookshelf.mml.ox.ac.uk/2015/12/09/from-saint-nicolas-to-petit-papa-noel/)
- [Saint Nicholas Center on customs in France](https://www.stnicholascenter.org/around-the-world/customs/france)
