# Le Réveillon du Nouvel An

## Email

- **Subject:** Three French expressions for the New Year
- **Preview text:** French Atelier explains what to say, what it means and when to use it.
- **Headline:** Wish someone a happy New Year in French
- **CTA:** Learn New Year French
- **Destination:** corresponding Le Réveillon du Nouvel An landing page; map to Sandra’s published URL before send.
- **Body word count:** 119 (required 100–150).

Bonjour,

Learn three French expressions you can use at New Year with French Atelier, and understand the celebration behind them.

Around a candlelit table, friends share le réveillon du Nouvel An, a late festive meal or gathering. Réveillon is connected to réveiller, “to wake up”. New Year’s Eve is also called la Saint-Sylvestre.

Greet someone with « Bonne année ! »: “Happy New Year!” Write « Meilleurs vœux ! » for “Best wishes!” Raise a glass with « À votre santé ! »: “Cheers!”

Some families kiss beneath le gui, mistletoe, but customs vary between households. Réveillon can also refer to Christmas Eve, so the full phrase matters.

Practise each expression aloud. Our guide explains when to use it, so you can join a New Year conversation in French.

[Learn New Year French]

À bientôt,
The French Atelier team

## Landing page

# What to say in French at New Year

Practise French you can use in a greeting, a message or a toast with French Atelier. Learn which expression fits each situation, and understand le réveillon du Nouvel An: a late festive meal whose name is connected to réveiller, “to wake up”.

## Two celebrations called réveillon

French uses réveillon for both the Christmas Eve celebration, le réveillon de Noël, and the New Year’s Eve celebration, le réveillon du Nouvel An. The rest of the phrase tells you which one is meant. La Saint-Sylvestre is another name for New Year’s Eve, while réveillon describes the late festive meal or gathering.

## A table, but not one fixed menu

Some people prepare dinner at home; others choose a restaurant or a larger party. A quiet gathering can be just as much a réveillon as a lively evening with many guests. There is no universal menu, and the details depend on the people around the table. Conversation and the anticipation of midnight are often as important as the food.

## Wishes that continue after midnight

Bonne année ! means “Happy New Year!” and Meilleurs vœux ! means “Best wishes!” You can say these to friends, relatives or neighbours, or write them in a short message. In France, New Year wishes often continue through January, rather than belonging only to the first moments of the year. For a toast, À votre santé ! means “Cheers!” or, more literally, “To your health!”

## Recognise the custom, choose your words

Le gui means mistletoe. Some families or couples kiss beneath it at New Year, but not everyone follows this custom. For a little French practice, imagine three situations: greeting a neighbour, writing a card and raising a glass. Choose Bonne année !, Meilleurs vœux ! or À votre santé ! for each. Say your choices aloud, then check their meanings in the section above.

Landing-page word count: 299, including section headings; excluding title, branding and references (required 250–350).

## Editorial fact-check references

- [France.fr on New Year celebrations and customs](https://www.france.fr/de/artikel/sylvester-frankreich/)
- [Larousse: réveillon, its meaning and derivation](https://www.larousse.fr/dictionnaires/francais/r%C3%A9veillon/69069)
